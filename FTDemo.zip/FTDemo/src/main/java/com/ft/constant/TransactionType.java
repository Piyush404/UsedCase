package com.ft.constant;

public enum TransactionType {
	
	DEBIT,CREDIT;

}
