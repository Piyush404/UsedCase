package com.ft.dto;

import org.hibernate.validator.constraints.NotEmpty;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


/**
 * @author piyush.shirpurkar
 *
 */
public class UserDTO {

	private int userId;
	@NotEmpty(message = "enter your username")
	private String username;
	@NotEmpty(message = "enter your password")
	private String password;
	@NotEmpty(message = "enter your phone number")
	private String phoneNo;
	@NotEmpty(message = "enter your email")
	private String email;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	

}
