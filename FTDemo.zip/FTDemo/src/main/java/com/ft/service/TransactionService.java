package com.ft.service;

import java.util.List;

import com.ft.Exception.InsufficientBalanceException;
import com.ft.dto.TransactionDTO;

public interface TransactionService {

	void transferFund(TransactionDTO transactionDTO) throws InsufficientBalanceException;

	List<TransactionDTO> getStatement(String accountNo);

}
