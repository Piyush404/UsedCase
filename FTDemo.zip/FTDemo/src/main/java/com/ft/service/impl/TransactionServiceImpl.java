package com.ft.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ft.DAO.TransactionDAO;
import com.ft.Exception.InsufficientBalanceException;
import com.ft.constant.TransactionType;
import com.ft.converter.TransactionConverter;
import com.ft.dto.TransactionDTO;
import com.ft.model.Transaction;
import com.ft.service.TransactionService;


/**
 * @author piyush.shirpurkar
 *
 */
@Service
public class TransactionServiceImpl implements TransactionService {

	@Autowired
	private TransactionDAO transactionDAO;

	@Autowired
	private TransactionConverter converter;

	/**
	 * @throws InsufficientBalanceException 
	 * @see com.ft.service.TransactionService#transferFund(com.ft.dto.TransactionDTO)
	 */
	public void transferFund(TransactionDTO transactionDTO) throws InsufficientBalanceException {
		Date date = new Date();
		java.sql.Date sqlDate = new java.sql.Date(date.getTime());
		transactionDTO.setDate(sqlDate);
		transactionDTO.setType("Debit");
		Transaction transaction = converter.convertDTOToEntity(transactionDTO);
		transactionDAO.transferFund(transaction);
	}

	/**
	 * @see com.ft.service.TransactionService#getStatement(java.lang.String)
	 */
	public List<TransactionDTO> getStatement(String accountNo) {
		List<Transaction> transactions = transactionDAO.getStatement(accountNo);
		List<TransactionDTO> dtos = converter.convertEntityToDTO(transactions);
		return dtos;
	}
}