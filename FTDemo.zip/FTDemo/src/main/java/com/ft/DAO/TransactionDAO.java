package com.ft.DAO;

import java.util.List;

import com.ft.Exception.InsufficientBalanceException;
import com.ft.model.Transaction;

public interface TransactionDAO {

	void transferFund(Transaction transaction) throws InsufficientBalanceException;

	List<Transaction> getStatement(String accountNo);

}
