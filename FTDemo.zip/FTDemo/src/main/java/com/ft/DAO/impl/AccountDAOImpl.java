package com.ft.DAO.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ft.DAO.AccountDAO;
import com.ft.model.Account;


/**
 * @author piyush.shirpurkar
 *
 */
@Repository
public class AccountDAOImpl implements AccountDAO {

	@Autowired
	private SessionFactory sessionFactory;

	
	public Account getAccountDetails(int userid) {
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Query query = session.createQuery("from Account a where a.userId =:userid");
		query.setInteger("userid", userid);
		List<Account> accounts = query.list();
		Account account = accounts.get(0);
		return account;
	}
	
	/** 
	 * @see com.ft.DAO.AccountDAO#getAccountDetailsByAccountNumber(java.lang.String)
	 */
	public Account getAccountDetailsByAccountNumber(String accountNo) {
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Query query = session.createQuery("from Account a where a.accountNo =:accountNo");
		query.setString("accountNo", accountNo);
		List<Account> accounts = query.list();
		if (accounts.isEmpty()) {
			return null;
		}
		Account account = accounts.get(0);
		return account;
	}
	
	/**
	 * @see com.ft.DAO.AccountDAO#updateAccount(com.ft.model.Account)
	 */
	public void updateAccount(Account account) {
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		session.saveOrUpdate(account);
		transaction.commit();
		session.close();
		
	}

}
