package com.ft.DAO.impl;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ft.DAO.AccountDAO;
import com.ft.DAO.TransactionDAO;
import com.ft.Exception.InsufficientBalanceException;
import com.ft.model.Account;
import com.ft.model.Transaction;


/**
 * @author piyush.shirpurkar
 *
 */
@Repository
public class TransactionDAOImpl implements TransactionDAO {

	private Logger logger = Logger.getLogger(TransactionDAOImpl.class);

	@Autowired
	private SessionFactory sessionFactory;

	@Autowired
	private AccountDAO accountDAO;
	
	/**(non-Javadoc)
	 * @throws InsufficientBalanceException 
	 * @see com.ft.DAO.TransactionDAO#transferFund(com.ft.model.Transaction)
	 */
	public void transferFund(Transaction transaction) throws InsufficientBalanceException {
		Session session = sessionFactory.openSession();
		org.hibernate.Transaction tran = session.beginTransaction();
		Account account = accountDAO.getAccountDetailsByAccountNumber(transaction.getAccountNo());
		if (account.getBalance() < transaction.getAmount()) {
			throw new InsufficientBalanceException("Balance is low");
		}
		double newBal = account.getBalance() - transaction.getAmount();
		account.setBalance(newBal);
		accountDAO.updateAccount(account);
		Account accountben = accountDAO.getAccountDetailsByAccountNumber(transaction.getAccountnoben());
		if (accountben == null) {
			logger.info("benficiary invalid : " + transaction.getAccountnoben());
		}else{
			double newBalBen = accountben.getBalance() + transaction.getAmount();
			accountben.setBalance(newBalBen);
			accountDAO.updateAccount(accountben);
			
			Transaction trans = new Transaction();
			trans.setAccountNo(accountben.getAccountNo());
			trans.setAccountnoben(transaction.getAccountNo());
			trans.setAmount(transaction.getAmount());
			trans.setDescription(transaction.getDescription());
			Date date = new Date();
			java.sql.Date sqlDate = new java.sql.Date(date.getTime());
			trans.setDate(sqlDate);
			trans.setType("Credit");
			session.save(trans);
		}
		
		session.save(transaction);
		tran.commit();
		logger.info("transfer completed");
		session.close();
	}

	/**
	 * @see com.ft.DAO.TransactionDAO#getStatement(java.lang.String)
	 */
	public List<Transaction> getStatement(String accountNo) {
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Query query = session.createQuery("from Transaction t where t.accountNo = :accountNo");
		query.setString("accountNo", accountNo);
		List<Transaction> transactions = query.list();
		return transactions;
	}

}
