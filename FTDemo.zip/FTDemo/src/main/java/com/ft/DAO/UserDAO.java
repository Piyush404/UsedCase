package com.ft.DAO;

import com.ft.model.User;

public interface UserDAO {

	User validateUser(String username, String password);

	User getUserByUserId(int userid);

}
