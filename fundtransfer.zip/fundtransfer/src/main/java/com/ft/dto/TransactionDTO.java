package com.ft.dto;

import java.util.Date;

import org.hibernate.validator.constraints.NotEmpty;

import com.ft.constants.TransactionType;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


/**
 * @author piyush.shirpurkar
 *
 */
public class TransactionDTO {

	private int transactionId;
	@NotEmpty(message = "enter your account number")
	private String accountNo;
	@NotEmpty(message = "enter beneficiary account number")
	private String accountnoben;
	private Date date;
	private double amount;
	private String type;
	@NotEmpty(message = "enter transaction remarks")
	private String description;
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountnoben() {
		return accountnoben;
	}
	public void setAccountnoben(String accountnoben) {
		this.accountnoben = accountnoben;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	

}
