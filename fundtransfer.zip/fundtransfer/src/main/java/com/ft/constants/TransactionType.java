package com.ft.constants;

public enum TransactionType {
	
	DEBIT,CREDIT;

}
