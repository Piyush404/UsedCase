package com.ft.DAO.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ft.DAO.UserDAO;
import com.ft.model.User;


/**
 * @author piyush.shirpurkar
 *
 */
@Repository
public class UserDAOImpl implements UserDAO {
	
	@Autowired
	private SessionFactory sessionFactory;

	/**
	 * @see com.ft.DAO.UserDAO#validateUser(java.lang.String, java.lang.String)
	 */
	public User validateUser(String username, String password) {
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Query query = session.createQuery("from User u where u.username = :username and u.password=:password");
		query.setString("username", username);
		query.setString("password", password);
		List<User> users = query.list();
		if (users.isEmpty()) {
			return null;
		}
		User user = users.get(0);
		return user;
	}

	public User getUserByUserId(int userid) {
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		User user = (User) session.get(User.class, userid);
		return user;
	}

}
