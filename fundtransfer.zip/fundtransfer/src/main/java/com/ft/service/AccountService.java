package com.ft.service;

import com.ft.dto.AccountDTO;

public interface AccountService {

	AccountDTO getAccountDetails(int userid);

}
