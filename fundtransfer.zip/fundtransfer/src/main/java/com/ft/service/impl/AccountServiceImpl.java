package com.ft.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ft.DAO.AccountDAO;
import com.ft.converter.AccountConverter;
import com.ft.dto.AccountDTO;
import com.ft.model.Account;
import com.ft.service.AccountService;


/**
 * @author piyush.shirpurkar
 *
 */
@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	private AccountDAO accountDAO;

	@Autowired
	private AccountConverter converter;

	/**
	 * @see com.ft.service.AccountService#getAccountDetails(int)
	 */
	public AccountDTO getAccountDetails(int userid) {
		Account account = accountDAO.getAccountDetails(userid);
		AccountDTO accountDTO = converter.convertAccountToDTO(account);
		return accountDTO;
	}

}
