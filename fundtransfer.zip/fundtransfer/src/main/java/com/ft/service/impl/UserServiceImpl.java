package com.ft.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ft.DAO.UserDAO;
import com.ft.converter.UserConverter;
import com.ft.dto.UserDTO;
import com.ft.model.User;
import com.ft.service.UserService;


/**
 * @author piyush.shirpurkar
 *
 */
@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDAO userDAO;

	@Autowired
	private UserConverter converter;

	/**
	 * (non-Javadoc)
	 * 
	 * @see com.ft.service.UserService#valdiateUser(java.lang.String,
	 *      java.lang.String)
	 */
	public UserDTO valdiateUser(String username, String password) {
		User user = userDAO.validateUser(username, password);
		if (user == null) {
			return null;
		}
		UserDTO userDTO = converter.convertUserTODTO(user);
		return userDTO;
	}

	public UserDTO getUserByUserId(int userid) {
		User user = userDAO.getUserByUserId(userid);
		UserDTO userDTO = converter.convertUserTODTO(user);
		return userDTO;
	}

}
