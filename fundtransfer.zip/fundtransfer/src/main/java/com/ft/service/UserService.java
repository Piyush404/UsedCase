package com.ft.service;

import com.ft.dto.UserDTO;

public interface UserService {

	UserDTO valdiateUser(String username, String password);

	UserDTO getUserByUserId(int userid);

}
